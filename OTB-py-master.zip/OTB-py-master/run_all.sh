 python run_trackers.py -t SimFC -s cvpr13
 python run_trackers.py -t SimFC -s tb50
 python run_trackers.py -t SimFC -s tb100
