Functions for running trackers.
You can add your script files. 
    - form : run_<tracker_name>(seq, resultpath, saveimage)
    - return : dictonary type variable (has 'res', 'type', 'fps' fileds)
You must import them in '__init__.py' and add exe(or matlab script) file into tracker_benchmark/trackers/<tracker_name>/
