import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from PIL import Image
from config import *
from scripts import *

colors = ["#ff00ff","#0000ff","#ff0000"]

def main():
    evalTypes = ['OPE', 'SRE', 'TRE']
    print "Eval types"
    for i in range(len(evalTypes)):
        evalType = evalTypes[i]
        print "{0:2d}. {1}".format(i+1, evalType)

    while True:
        n = int(raw_input("\nInput evalType number (-1 to exit) : "))
        if n == -1:
            sys.exit()
        try:
            evalType = evalTypes[n-1]
            break
        except:
            print "invalid number"

    src = RESULT_SRC.format(evalType)
    trackers = os.listdir(src)
    trackers.sort()
    print "\nTrackers"
    for i in range(len(trackers)):
        t = trackers[i]
        print "{0:2d}. {1}".format(i+1, t)

    bbox_trackers = []
    while True:
        n = int(raw_input("\nInput tracker number (-1 to exit, -2 to finish input) : "))
        if n == -1:
            sys.exit()
        elif n == -2:
            break
        try:
            bbox_trackers.append(trackers[n-1])
            print trackers[n-1]
        except:
            print "invalid number"


    srcs = [(src + '/' + tracker + '/') for tracker in bbox_trackers]
    src = srcs[0]
    bbox_results = []
    seqs = [x for x in os.listdir(src) if x.endswith('.json')]
    seqs.sort()    
  
    while True:
        print "\nSequences"
        for i in range(len(seqs)):
            s = seqs[i]
            print "{0:2d}. {1}".format(i+1, s)
        results = []
        n_seqs = int(raw_input("\nInput sequence number (-1 to exit) : "))
        if n_seqs == -1:
            sys.exit()
        try:
            resultFile = open(os.path.join(src, seqs[n_seqs-1]))
            print seqs[n_seqs-1]
        except:
            print "invalid number"

        string = resultFile.read()
        jsonList = json.loads(string)
        for j in jsonList:
            result = Result(**j)
            results.append(result)

        for i in range(len(results)):
            result = results[i]
            print "{0:2d}. startFrame : {1},\tshiftType : {2}".format(i+1, result.startFrame, result.shiftType)

        n_res = int(raw_input("\nInput result number (-1 to exit) : "))
        if n_res == -1:
            sys.exit()
        try:
            for src in srcs:
                results = []
                resultFile = open(os.path.join(src, seqs[n_seqs-1]))
                string = resultFile.read()
                jsonList = json.loads(string)
                for j in jsonList:
                    result = Result(**j)
                    results.append(result)
                bbox_results.append(results[n_res-1])
            for i_src, src in enumerate(srcs):
                print i_src,colors[i_src],src
            break
        except:
            print "invalid number"
            continue

    seq = butil.load_seq_config(bbox_results[0].seqName)
    # print result.res
    bbox_all_res = [result.res for result in bbox_results]
    print 'len(bbox_all_res) =',len(bbox_all_res)
    startFrame = bbox_results[0].startFrame
    view_result_save(seq, bbox_all_res, startFrame)
    
def view_result_save(seq, bbox_all_res, startIndex):
    print 'processing..'
    for i in xrange(startIndex,startIndex+len(bbox_all_res[0])):
        if (i%100)==0:
            print i
        fig = plt.figure()

        src = os.path.join(SEQ_SRC, seq.name)
        try:
            image = Image.open(src + '/img/{0:04d}.jpg'.format(i)).convert('RGB')
        except:
            image = Image.open(src + '/img/{0:05d}.jpg'.format(i)).convert('RGB')
        im = plt.imshow(image, zorder=0)
        for i_res, res in enumerate(bbox_all_res):
            x, y, w, h = get_coordinate(res[i-seq.startFrame])
            rect = plt.Rectangle((x, y), w, h, 
            linewidth=2, edgecolor=colors[i_res], zorder=1, fill=False)
            plt.gca().add_patch(rect)
        gx, gy, gw, gh = get_coordinate(seq.gtRect[i-seq.startFrame])
        gtRect = plt.Rectangle((gx, gy), gw, gh, 
        linewidth=2, edgecolor="#00ff00", zorder=1, fill=False)
        h, w = image.size
        plt.text(10, 40, '#{0:04d}'.format(i), fontsize=20,color='#ffff00')
        plt.gca().add_patch(gtRect)
        plt.axis('off')

        plt.savefig('draw_bbox/'+seq.name+'_'+str(i)+'.jpg')
        plt.close()
def view_result(seq, res, startIndex):
    fig = plt.figure()

    src = os.path.join(SEQ_SRC, seq.name)
    image = Image.open(src + '/img/{0:04d}.jpg'.format(startIndex)).convert('RGB')
    im = plt.imshow(image, zorder=0)

    x, y, w, h = get_coordinate(res[0])
    gx, gy, gw, gh = get_coordinate(seq.gtRect[startIndex-seq.startFrame])

    rect = plt.Rectangle((x, y), w, h, 
      linewidth=5, edgecolor="#ff0000", zorder=1, fill=False)
    gtRect = plt.Rectangle((gx, gy), gw, gh, 
      linewidth=5, edgecolor="#00ff00", zorder=1, fill=False)
    plt.gca().add_patch(rect)
    plt.gca().add_patch(gtRect)

    def update_fig(num, startIndex, res, gt, src, startFrame):    
        r = res[num]
        g = gt[num+startIndex-startFrame]
        x, y, w, h = get_coordinate(r)
        gx, gy, gw, gh = get_coordinate(g)
        i = startIndex + num
        image = Image.open(src + '/img/{0:04d}.jpg'.format(i)).convert('RGB')
        im.set_data(image)
        rect.set_xy((x,y))
        rect.set_width(w)
        rect.set_height(h)
        gtRect.set_xy((gx,gy))
        gtRect.set_width(gw)
        gtRect.set_height(gh)
        return im, rect, gtRect

    ani = animation.FuncAnimation(fig, update_fig, 
        frames=len(res), fargs=(startIndex, res, seq.gtRect, src, seq.startFrame), interval=10, blit=True)
    plt.axis("off")
    plt.show()

def get_coordinate(res):
    return int(res[0]), int(res[1]), int(res[2]), int(res[3])
  

if __name__ == '__main__':
    main()
